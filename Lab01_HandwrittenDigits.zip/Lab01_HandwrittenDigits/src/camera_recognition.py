# camera_recognition.py
# This script uses the trained model to recognize digits from a live webcam feed on Windows.

import cv2
import numpy as np
from tensorflow.keras.models import load_model

# Load the pre-trained model
# Ensure the 'handwritten_digit_model.h5' file is in the same directory.
try:
    model = load_model('handwritten_digit_model.h5')
except Exception as e:
    print(f"Error loading model: {e}")
    print("Please make sure 'handwritten_digit_model.h5' is in the same directory as the script.")
    exit()

# Function to preprocess the image for the model
def preprocess_image(img):
    """
    Preprocesses a captured image frame to match the MNIST format.
    - Converts to grayscale
    - Applies thresholding to create a binary image
    - Finds contours to isolate the digit
    - Resizes the digit to 28x28 pixels
    - Inverts colors (model was trained on white digits on a black background)
    - Normalizes the pixel values
    - Reshapes for model input
    """
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Apply Gaussian blur to reduce noise and improve thresholding
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # Apply adaptive thresholding to get a binary image
    # This helps to handle different lighting conditions
    thresh = cv2.adaptiveThreshold(blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 2)

    # Find contours in the thresholded image
    contours, _ = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Get the bounding box of the largest contour (assumed to be the digit)
    if contours:
        c = max(contours, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(c)

        # Add some padding to the bounding box
        padding = 20
        x, y, w, h = x - padding, y - padding, w + 2*padding, h + 2*padding
        x, y = max(0, x), max(0, y)

        # Extract the digit from the original frame
        digit_roi = thresh[y:y+h, x:x+w]

        if digit_roi.size > 0:
            # Resize the ROI to 28x28, which is the input size for our model
            resized_digit = cv2.resize(digit_roi, (28, 28), interpolation=cv2.INTER_AREA)

            # Normalize the image (scale pixel values to be between 0 and 1)
            normalized_digit = resized_digit.astype('float32') / 255.0

            # Reshape for the model: (1, 28, 28, 1)
            reshaped_digit = np.reshape(normalized_digit, (1, 28, 28, 1))

            # Draw rectangle around the detected digit for visualization
            cv2.rectangle(img, (x, y), (x+w, y+h), (0, 255, 0), 2)

            return reshaped_digit, img

    return None, img


# Start video capture from the default camera (index 0)
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Error: Could not open camera.")
    exit()

while True:
    # Read a frame from the camera
    ret, frame = cap.read()
    if not ret:
        break

    # Flip the frame horizontally for a more intuitive mirror-like display
    frame = cv2.flip(frame, 1)

    # Preprocess the frame to get a potential digit
    processed_digit, display_frame = preprocess_image(frame.copy())

    prediction_text = "Prediction: None"

    if processed_digit is not None:
        # Make a prediction with the model
        prediction = model.predict(processed_digit)
        # Get the digit with the highest probability
        predicted_digit = np.argmax(prediction)
        confidence = np.max(prediction)

        # Create the text to display
        prediction_text = f"Prediction: {predicted_digit} ({confidence*100:.2f}%)"

    # Overlay the prediction text on the frame
    cv2.putText(display_frame, prediction_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2, cv2.LINE_AA)

    # Show the resulting frame
    cv2.imshow('Handwritten Digit Recognition - Press Q to Quit', display_frame)

    # Break the loop if 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the camera and destroy all windows
cap.release()
cv2.destroyAllWindows()